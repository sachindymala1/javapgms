package com.company;

public class Main {

    public static void main(String[] args) {
	car obj1= new BMW();
    obj1.milage();
    car obj2=new Swift();// write your code here
        obj2.engine();
    }
}

abstract  class car{

    abstract  void design();
    abstract void milage();
    abstract void engine();


}
class BMW extends  car{
    @Override
    void design() {
        System.out.println("premium german design");
    }
    void milage (){
        System.out.println("8kmpl ");
    }
    void engine(){
        System.out.println("S65 V8-E92 M3GTS petrole with 450hp");
    }




}
class Swift extends car{
    void design() {
        System.out.println("Design suited for Indian market");
    }
    void milage (){
        System.out.println("24kmpl ");
    }
    void engine(){
        System.out.println("1.2l 4cylinder diesel with 74 hp  ");
    }

}