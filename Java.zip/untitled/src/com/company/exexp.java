package com.company;

import java.io.IOException;

public  class exexp {
    static void combi(int arr[],int index) {
        int count=0;
        if (index == arr.length) {
            for (int i = 0; i < arr.length; i++) {
                System.out.print(arr[i] + " ");
                count++;
            }
            System.out.println();

        }

        for (int i = index; i < arr.length; i++) {
            int temp = arr[index];
            arr[index] = arr[i];
            arr[i] = temp;
            combi(arr, index + 1);

            temp = arr[index];
            arr[index] = arr[i];
            arr[i] = temp;
        }
    }






}
//student info
//unique usn(key)
//map(string,map)
// inside for loop create a map(string ,string)>studentinfo
//map stidentinfi=student.get ("4mn16isji");
//studentinfo.get("name");