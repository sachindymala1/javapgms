public class Contact {
    private String firstName;
    private String lastName;
    private String phoneNumber;

    public Contact(String firstName,String lastName,String phoneNumber){
        this.firstName=firstName;
        this.lastName=lastName;
        this.phoneNumber=phoneNumber;
    }

    public  String getFirstName(){
        return firstName;
    }

    public  void setFirstName(String firstName){
        this.firstName =firstName;
    }

    public  String getlastName(){
        return lastName;
    }

    public  void setlastName(String lastName){
        this.lastName =lastName;
    }

    public  String getPhoneNumber(){
        return phoneNumber;
    }

    public  void setPhoneNumber(String phoneNumber){
        this.phoneNumber =phoneNumber;
    }

    public void validateFirstName(){
        if(this.firstName==null){
            throw new RuntimeException("First Name Cannot be Null");
        }
    }

    public void validateLastName(){
        if(this.lastName==null){
            throw new RuntimeException("last Name Cannot be Null");
        }
    }

    public void validatePhoneNumber(){
        if(this.phoneNumber.length()!=10){
            throw new RuntimeException("Phone Number should be 10 digit long  ");
        }
        if(!this.phoneNumber.matches("\\d+")){
            throw new RuntimeException("Phone Number should Contain only Digits");
        }
        if(!this.phoneNumber.startsWith("0")) {
            throw new RuntimeException("Phone Number should strat with 0 in India");
        }
    }

}
