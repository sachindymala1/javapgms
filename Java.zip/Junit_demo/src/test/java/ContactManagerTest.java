import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

class ContactManagerTest {
    private static  ContactManager contactManager;

    @BeforeAll
    public static void setupAll(){
        System.out.println("Should print Before all Tests");

    }

    @BeforeEach
    public void setup(){
        System.out.println("Instatiating contact Manager");
        contactManager =new ContactManager();

    }


    @Test
    @DisplayName("Should Create Contact")
    public void sholudCreateContact(){
        ContactManager contactManager=new ContactManager();
        contactManager.addContact("Sachin","ks","0701946503");
        Assertions.assertFalse(contactManager.getAllContact().isEmpty());
        Assertions.assertEquals(1,contactManager.getAllContact().size());

    }
    @Test
    @DisplayName("Should not create contact when first name is null")
    public void shouldThrowErrorWhenFirstNameIsNull(){
        ContactManager contactManager=new ContactManager();
        assertThrows(RuntimeException.class,()->{
            contactManager.addContact(null,"ks" ,"0123456789");
        });
    }
    @Test
    @DisplayName("Should not create contact when Phone Number  is null")
    public void shouldThrowErrorWhenPhoneNumberIsNull(){
        ContactManager contactManager=new ContactManager();
        assertThrows(RuntimeException.class,()->{
            contactManager.addContact("sachin","ks" ,null);
        });
    }

    @AfterEach
    public  void finish(){
        System.out.println("Should Execute after Each Test");

    }
    @AfterAll
    public static  void finishAll(){
        System.out.println("Should Execute at the end of the test");
  }
}