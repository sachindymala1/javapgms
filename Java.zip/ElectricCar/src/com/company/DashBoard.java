package com.company;

public interface DashBoard {
    public void Screen();
    public void UI();
    public void Soc();
}
