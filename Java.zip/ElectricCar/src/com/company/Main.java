package com.company;

public class Main {

    public static void main(String[] args) {
        ModelA m1 = new ModelA();
        m1.accelaration();
    }
}
