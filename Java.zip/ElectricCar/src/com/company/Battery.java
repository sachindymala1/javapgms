package com.company;

public interface Battery {
    public void capacity();
    public void range();
    public void Size();
}
