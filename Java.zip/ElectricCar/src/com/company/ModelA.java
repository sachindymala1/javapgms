package com.company;

public class ModelA implements DashBoard,Motor,chassis,Battery{
    public void Screen(){
        System.out.println("tft screen");
    }
    public void UI(){
        System.out.println("Custome designed UI");
    }
    public void Soc(){
        System.out.println("D1 FSD");
    }
    public void power(){
        System.out.println("3500 hp");
    }
    public void cunsumption(){
        System.out.println("10KWpH at 60 kmph");
    }
    public void accelaration(){
        System.out.println("0-60 in 2s");
    }
    public void design(){
        System.out.println("tubular");
    }
    public void material(){
        System.out.println("alluminaum alloy");
    }
    public void capacity(){
        System.out.println("100kwh");
    }
    public void range(){
        System.out.println("600km");
    }
    public void Size(){
        System.out.println("5feet* 4feet");
    }
}
