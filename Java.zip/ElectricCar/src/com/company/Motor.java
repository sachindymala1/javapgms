package com.company;

public interface Motor {
    public void power();
    public void cunsumption();
    public void accelaration();
}
