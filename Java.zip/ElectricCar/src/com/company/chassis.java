package com.company;

public interface chassis {
    public void design();
    public void material();
}
