package com.company;

public interface modelS {

}
