package com.company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main implements UserInter,BookInter,CartInter {
    static Scanner sc = new Scanner(System.in);
    private static Connection con;
    private static Statement stm;
    public static void main(String[] args) throws SQLException {

        try {
            String address = "jdbc:mysql://localhost:3306/library";
            String user = "root";
            String pass = "root";
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(address, user, pass);
            stm = con.createStatement();
             options op=new options();
            op.option();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            con.close();
        }
    }

    @Override
    public void adduser() {

    }
    @Override
    public void insert() {

    }

    @Override
    public void delete() {

    }

    @Override
    public void displayBook() {

    }

    @Override
    public void update() {

    }

    @Override
    public void addBooktoCart() {

    }

    @Override
    public void deleteBookfrom() {

    }

    @Override
    public void displayBookfromCart() {

    }

    @Override
    public void checkUserinList() {

    }



    @Override
    public void deleteuser() {

    }

    @Override
    public void updateuser() {

    }

    @Override
    public void display() {

    }
}
