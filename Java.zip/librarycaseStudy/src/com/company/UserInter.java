package com.company;

public interface UserInter {
    public  void adduser();

    public  void deleteuser();

    public  void updateuser();
    public  void display();
}
