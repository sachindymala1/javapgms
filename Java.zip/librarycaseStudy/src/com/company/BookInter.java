package com.company;

public interface BookInter {
    public void insert();
    public void delete();
    public void displayBook();
    public void update();
}
