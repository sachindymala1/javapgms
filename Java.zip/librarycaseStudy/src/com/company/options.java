package com.company;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class options extends Main{

    public  void option() throws SQLException, ClassNotFoundException {


        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("please chose your option");
            System.out.println("1:Book Store\n2:User\n3:Cart\n4:exit");
            int option = sc.nextInt();
            switch (option) {
                case 1:
                    bookoperation();
                    break;
                case 2:
                    useroperation();
                    break;
                case 3:
                    cartoperation();
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("choose the correct option");
            }
        }

    }
    public  void bookoperation(){
        System.out.println("please chose your option");
        System.out.println("option on book store:\n1:Inseet\n2:Delete \n3:Display\n4:Update");
        int option=sc.nextInt();
        switch (option){
            case 1:
               insert();
                break;
            case 2:
                delete();
                break;
            case 3:
                displayBook();
                break;
            case  4:
                update();
            case 5:
                System.exit(0);
                break;
            default:
                System.out.println("choose the correct option");

        }


    }
    public  void useroperation() throws SQLException, ClassNotFoundException {
        System.out.println("please chose your option");
        System.out.println("option of user :\n 1:Adduser\n2:Delete user\n3:Update user\n 4:display,..");
        int option=sc.nextInt();
        switch (option) {
            case 1:
                adduser();
                break;

            case 2:
                deleteuser();
                break;
            case 3:
                updateuser();
                break;
            case 4:
                display();
                break;
            case 5:
                System.exit(0);
                break;
            default:
                System.out.println("choose the correct option");
        }

    }

    public  void cartoperation(){
        System.out.println("please chose your option");
        System.out.println("option of user :\n 1:Add book to cart\n2:Delete book from cart\n3:display book from cart\n 4:check user in list,..");
        int option=sc.nextInt();
        switch (option) {
            case 1:
                addBooktoCart();
                break;
            case 2:
                deleteBookfrom();
                break;
            case 3:
                displayBookfromCart();
                ;
                break;
            case 4:
                checkUserinList();
                break;
            case 5:
                System.exit(0);
                break;
            default:
                System.out.println("choose the correct option");
        }

    }



}