package com.company;
import java.util.*;
import java.util.ArrayList;

public class lists {
    ArrayList<String> cars= new ArrayList<String>();
        cars.add("BMW");
        cars.add("Toyota");
        cars.add("Tesla");
        System.out.println("car companies"+cars);
    ArrayList<String> countryoforigin= new ArrayList<String>();
        countryoforigin.add("Germany");
        countryoforigin.add("Japan");
        countryoforigin.add("USA");
        System.out.println("Country of origin"+countryoforigin);
        countryoforigin.addAll(cars);

        System.out.println("added list"+countryoforigin);
}
