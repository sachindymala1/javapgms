package com.company;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Librery implements UserInter,BookInter,CartInter {
    String addr = "jdbc:mysql://localhost:3306/librery";
    String username = "root";
    String password = "root";
    Scanner sc= new Scanner(System.in);
    private static Connection con ;
    private static Statement stm;

    public  void option() throws SQLException, ClassNotFoundException {

        Class.forName("com.mysql.cj.jdbc.Driver");
        System.out.println("Connected!!!");
        con = DriverManager.getConnection(addr, username, password);
        stm=con.createStatement();
        Scanner sc= new Scanner(System.in);
        while (true)
        {
            System.out.println("please chose your option");
        System.out.println("1:Book Store\n2:User\n3:Cart\n4:exit");
        int option=sc.nextInt();
        switch (option) {
            case 1:
                bookoperation();
                break;
            case 2:
                useroperation();
                break;
            case 3:
                cartoperation();
                break;
            case 4:
                System.exit(0);
                break;
            default:
                System.out.println("choose the correct option");
        }
    }
    }
    public  void adduser() throws SQLException, ClassNotFoundException {


            System.out.println("Enter user id:");
            int u_id = sc.nextInt();
            System.out.println("Enter userName :");
            String user_name = sc.next();
            System.out.println("Enter password :");
            String pass = sc.next();
            System.out.println("Enter place :");
            String place = sc.next();
            String sqlInsert = "insert into user values(?,?,?,?)";
            PreparedStatement pstm = con.prepareStatement(sqlInsert);
            pstm.setInt(1, u_id);
            pstm.setString(2, user_name);
            pstm.setString(3, pass);
            pstm.setString(4, place);
            int status = pstm.executeUpdate();
            if (status == 0) {
                System.out.println("Enter different user id ");
            } else {
                System.out.println("Insertion done ");
            }
        }



    public  void bookoperation(){
        System.out.println("please chose your option");
        System.out.println("option on book store:\n1:Inseet\n2:Delete \n3:Display\n4:Update");
        int option=sc.nextInt();
        switch (option){
            case 1:
                insert();
                break;
            case 2:
                delete();
                break;
            case 3:
                displayBook();
                break;
            case  4:
                update();
            case 5:
                System.exit(0);
                break;
            default:
                System.out.println("choose the correct option");

        }


    }

    public  void useroperation() throws SQLException, ClassNotFoundException {
        System.out.println("please chose your option");
        System.out.println("option of user :\n 1:Adduser\n2:Delete user\n3:Update user\n 4:display,..");
        int option=sc.nextInt();
        switch (option) {
            case 1:
               adduser();
                break;

            case 2:
               deleteuser();
                break;
            case 3:
                updateuser();
                break;
            case 4:
                display();
                break;
            case 5:
                System.exit(0);
                break;
            default:
                System.out.println("choose the correct option");
        }

    }

    public  void cartoperation(){
        System.out.println("please chose your option");
        System.out.println("option of user :\n 1:Add book to cart\n2:Delete book from cart\n3:display book from cart\n 4:check user in list,..");
        int option=sc.nextInt();
        switch (option) {
            case 1:
                addBooktoCart();
                break;
            case 2:
                deleteBookfrom();
                break;
            case 3:
                displayBookfromCart();
                ;
                break;
            case 4:
                checkUserinList();
                break;
            case 5:
                System.exit(0);
                break;
            default:
                System.out.println("choose the correct option");
        }

    }


    //user interface

    public  void deleteuser(){
        System.out.println("option");
    }
    public   void updateuser(){
        System.out.println("option");
    }
    public  void display(){
        System.out.println("option");
    }


//Book interface
    public void insert(){
        System.out.println("Insert Book");
    }
    public void delete(){
        System.out.println("delete book");
    }
    public void displayBook(){
        System.out.println("displaybook");
    }
    public void update(){
        System.out.println("update book");

    }

    //cart interface
    public  void addBooktoCart(){
        System.out.println("addBooktoCart");
    }
    public  void deleteBookfrom(){
        System.out.println("Delete book from cart");

    }
    public  void displayBookfromCart(){
        System.out.println("display book from cart");

    }

    public  void checkUserinList(){
        System.out.println("checkUserinList");
    }
}
