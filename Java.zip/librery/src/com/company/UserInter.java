package com.company;

import java.sql.SQLException;

public interface UserInter {
    public  void adduser() throws SQLException, ClassNotFoundException;

    public  void deleteuser();

    public  void updateuser();
    public  void display();
}
