package com.company;

public interface CartInter {
    public  void addBooktoCart();
    public  void deleteBookfrom();
    public  void displayBookfromCart();
    public  void checkUserinList();

}
