package com.company;

public interface UserInter {
}
