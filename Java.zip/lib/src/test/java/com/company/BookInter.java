package com.company;

public interface BookInter {
}
